from flask import Flask, jsonify
import os
import redis

app = Flask(__name__)

REDIS_HOST = os.getenv("REDIS_HOST", "redis")
REDIS_PORT = int(os.getenv("REDIS_PORT", "6379"))


def get_redis():
    return redis.Redis(host=REDIS_HOST, port=REDIS_PORT, decode_responses=True, socket_connect_timeout=2)


@app.get("/")
def home():
    return """<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>Docker DevOps Lab</title>
  <style>
    body { font-family: Arial, sans-serif; max-width: 760px; margin: 60px auto; padding: 0 20px; }
    .card { border: 1px solid #ddd; border-radius: 12px; padding: 24px; }
    code { background: #f4f4f4; padding: 3px 6px; border-radius: 5px; }
  </style>
</head>
<body>
  <div class="card">
    <h1>Docker DevOps Lab</h1>
    <p>This Flask application is running inside a Docker container.</p>
    <p>Redis is running as a second container managed by Docker Compose.</p>
    <p>Try <a href="/health">/health</a> and <a href="/counter">/counter</a>.</p>
  </div>
</body>
</html>"""


@app.get("/health")
def health():
    try:
        r = get_redis()
        r.ping()
        return jsonify(status="healthy", redis="connected")
    except redis.RedisError as exc:
        return jsonify(status="degraded", redis="unavailable", error=str(exc)), 503


@app.get("/counter")
def counter():
    try:
        r = get_redis()
        count = r.incr("page_views")
        return jsonify(page_views=count)
    except redis.RedisError as exc:
        return jsonify(error=str(exc)), 503


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
