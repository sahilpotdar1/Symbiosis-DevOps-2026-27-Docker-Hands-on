# Docker DevOps Lab

This lab containerizes a small Flask web application and then deploys it as a two-service application with Docker Compose.

## Folder structure

```text
docker-devops-lab/
├── app/
│   └── app.py
├── .dockerignore
├── Dockerfile
├── compose.yaml
├── requirements.txt
└── README.md
```

## What you will practice

- Docker image creation with a Dockerfile
- Running containers in foreground and detached mode
- Port publishing
- Container lifecycle commands
- Container filesystem inspection with `docker exec`
- Named volumes and persistence
- Image tagging and registry concepts
- Docker Compose with a web service and Redis
- Basic logs, health checks, cleanup, and troubleshooting

## Expected result

The application should be available at:

- http://localhost:8080
- http://localhost:8080/health
- http://localhost:8080/counter

For Windows, Docker Desktop should use the WSL 2 backend and Linux containers. For macOS, Docker Desktop is sufficient.
